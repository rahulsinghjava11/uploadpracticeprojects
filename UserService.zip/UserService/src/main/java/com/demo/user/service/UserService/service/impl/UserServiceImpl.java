package com.demo.user.service.UserService.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.demo.user.service.UserService.entity.Hotel;
import com.demo.user.service.UserService.entity.Rating;
import com.demo.user.service.UserService.entity.User;
import com.demo.user.service.UserService.exception.ResourceNotFoundException;
import com.demo.user.service.UserService.external.service.HotelService;
import com.demo.user.service.UserService.repository.UserRepository;
import com.demo.user.service.UserService.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);
	@Autowired
    private	UserRepository userRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private HotelService hotelService;
	
	@Override
	public User saveUser(User user) {
		String randomUserId = UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		return userRepository.save(user);
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User getUser(String userId) {
		
	User user =	userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User with given id is not found on server !!"+userId));
		// get rating for user from rating service
		
		// http://localhost:8083/ratings/users/00ab75ca-4c89-467c-b553-24c030425e5d
		
//	List<Rating> ratingOfUser =	restTemplate.getForObject("http://localhost:8083/ratings/users/"+userId, ArrayList.class);
	
//	Rating[] ratingOfUser =	restTemplate.getForObject("http://localhost:8083/ratings/users/"+userId, Rating[].class);
	Rating[] ratingOfUser =	restTemplate.getForObject("http://RATING-SERVICE/ratings/users/"+userId, Rating[].class);
	log.info(""+ratingOfUser);
	List<Rating> ratings = Arrays.asList(ratingOfUser);
	List<Rating>  ratingList = ratings.stream().map(rating -> {
		// api call to hotel service to get the Hotel
		// http://localhost:8082/hotels/8af6dc78-68ff-4ab8-8b6a-072c7b3218f6
		
	//	ResponseEntity<Hotel> response =	restTemplate.getForEntity("http://localhost:8082/hotels/"+rating.getHotelId(), Hotel.class);
	//	ResponseEntity<Hotel> response =	restTemplate.getForEntity("http://HOTEL-SERVICE/hotels/"+rating.getHotelId(), Hotel.class);
	//	Hotel hotel = response.getBody();
		Hotel hotel = hotelService.getHotel(rating.getHotelId());
		//set hotel to rating
		rating.setHotel(hotel);
		//return rating
		
		return rating;
	}).collect(Collectors.toList());
	user.setRatings(ratingList);
	return user;

	}

}
