package com.demo.user.service.UserService.exception;

public class ResourceNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7325409832728019944L;

	public ResourceNotFoundException() {
		super("Resource Not Found in server !!");
	}
	
	public ResourceNotFoundException(String message) {
		
		super(message);
	}
}
