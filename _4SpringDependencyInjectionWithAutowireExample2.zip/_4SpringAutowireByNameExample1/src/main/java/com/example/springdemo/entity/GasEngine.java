package com.example.springdemo.entity;

public class GasEngine implements Engine {

	@Override
	public void start() {
		// TODO Auto-generated method stub
     System.out.println("Starting Gas Engine....");
	}

}
