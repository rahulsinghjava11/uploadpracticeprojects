package com.example.springdemo.entity;

public class ManualTransmission implements Transmission {

	@Override
	public void shift() {
		// TODO Auto-generated method stub
       System.out.println("Shifting to manual Transmission");
	}

}
