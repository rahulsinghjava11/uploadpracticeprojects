package com.example.springdemo.entity;

public class AutomaticTransmission implements Transmission {

	@Override
	public void shift() {
		// TODO Auto-generated method stub
       System.out.println("Shifting to Automatic Transmission....");
	}

}
