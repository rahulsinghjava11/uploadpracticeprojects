package com.example.springdemo.entity;

public interface Engine {

	void start();
}
