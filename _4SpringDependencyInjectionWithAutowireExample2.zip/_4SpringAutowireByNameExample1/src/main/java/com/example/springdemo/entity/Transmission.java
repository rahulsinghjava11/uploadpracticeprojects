package com.example.springdemo.entity;

public interface Transmission {

	void shift();
}
