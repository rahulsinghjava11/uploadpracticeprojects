package com.demo.hotel.service.hotelservice.service;

import java.util.List;

import com.demo.hotel.service.hotelservice.entity.Hotel;

public interface HotelService {

	//create
	Hotel createHotel(Hotel hotel);
	
	//getAll
	List<Hotel>  getAllHotelDetsils();
	
	//getSingle
	Hotel getHotelDetails(String hotelId);
}
