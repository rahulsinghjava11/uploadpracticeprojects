package com.demo.rating.service.services;

import java.util.List;

import com.demo.rating.service.entities.Rating;

public interface RatingService {

	//create 
	
		Rating create(Rating rating);
		
		// get all rating 
		
		List<Rating> getAllRatings();
		
		
		// get all by userId
		List<Rating> getRatingByUser(String userId);
		
		
		// get All by Hotels
		
		List<Rating> getRatingByHotel(String hotelId);
}
